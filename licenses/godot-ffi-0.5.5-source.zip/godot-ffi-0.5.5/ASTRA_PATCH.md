# godot-ffi 0.5.5 visionOS registration fix

Upstream: https://github.com/godot-rust/gdext (crates.io godot-ffi 0.5.5).
Copyright godot-rust; Bromeon and contributors. MPL-2.0.

Only `src/shard_registry.rs` is changed: the constructor registration macro uses
Apple's `__DATA,__mod_init_func` section for `target_os = "visionos"`, just as it
already does for macOS and iOS. Without it the dylib loads, but its class and
method registration shards never run. The first device launch exposed missing
MqttLink, Wire, Sfx and GameFlow classes.

This directory is the corresponding source for the patched dependency. Keep its
license notices and make this source available with distributed binaries. Remove
the Cargo patch once a pinned upstream release includes visionOS constructors.
